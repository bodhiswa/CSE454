clc
clear
close all
data = load("synthetic_control.data");
% Creating PAA segments
train_label1 = data(1,:);
train_label2 = data(100,:);


test_label1 = data(1:100,:);
test_label2 = data(101:200,:);
test_label3 = data(201:300,:);
test_label4 = data(301:400,:);
test_label5 = data(401:500,:);
test_label6 = data(501:600,:);


c = 6; 
%label_class1 = data(1:100,:);
%label_class2 = data(101:200,:);
% label_class2 = data(101:200,1);
% label_class3 = data(201:300,1);
% label_class4 = data(301:400,1);
% label_class5 = data(401:500,1);
% label_class6 = data(501:600,1);                                      % number of windows
PAA_train = generate_PAA(c, data);
PAA_test1 = generate_PAA(c, test_label1);
% PAA_test2 = generate_PAA(c, test_label2);
% PAA_test3 = generate_PAA(c, test_label3);
% PAA_test4 = generate_PAA(c, test_label4);
% PAA_test5 = generate_PAA(c, test_label5);
% PAA_test6 = generate_PAA(c, test_label6);

plot_PAA(PAA_test1,data,c,2);

% Class 1

for i = 1:size(data,1)
    for j = 1:size(train_label1,1)
        orgD(i, j) = dist_calc(data(i), train_label1(j));
        %orgD(i, j) = dist_calc(data(i), train_label2(j));
    end
end

for i = 1:size(orgD, 1)
    [throwAway, orgClass(i)] = min(orgD(i,:));
end


% count1 = 0;
% len = length(orgClass);
% 
% for i= 1:len
%      d = orgClass(i) - test_label1(i);
%      if d == 0
%          count1 = count1 + 1;
%      end
% end
% accuracy = count1/length(orgClass);
% 
% % c = confusionmat(label, orgClass);
% % confusionchart(c);