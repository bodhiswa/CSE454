% trying to see all the data

clc
clear
[x_val, y_val] = load_data("synthetic_control.data");

% ---------------------- Preprocessing begins ----------------------

% Preprocessing 1 -- Removing empty rows.

for i = 1:(length(x_val))
    if i(1) == 0
        x_val(i, :) = [];
    end
end

load("synthetic_control.data");

% Pulling classes


% % Class 1 - Normal
% class1_norm = synthetic_control(:,1);
% % Removing class1_norm from dataset
% class1_free = synthetic_control(1,:);
% class1_free(:,1)
% % number of observations in class
% m = length(class1_free)
% t = linspace(1, 100, m)
% %plot(t, class1_free)
% hold on

%Class 2 - Cyclic
% class2_cyc = synthetic_control(:,1)
% class2_free = synthetic_control(2,:)
% % class2_free(:,2)
% m2 = length(class2_free)
% t2 = linspace(1,100,m2)
% plot(t2, class2_free)
% hold on

for j = 1:(length(synthetic_control))
    class_free = synthetic_control(j,:);
    m = length(class_free);
    t = linspace(1, 100, m);
    plot(t,class_free);
    hold off
end

me = mean(class_free)
st_dev = std(class_free)

% Normalizing the dataset
for i = 1:length(class_free)
    class_free(i) = (class_free(i)-me)/st_dev
end
plot(t, class_free)
hold off


% Creating PAA segments



