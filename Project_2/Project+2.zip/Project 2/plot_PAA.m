function plot_PAA(PAA,data,c,i)
s = (size(data));
dt = s(2);
len_ofseg = dt/c;                             % length of segment
len_ofseg = ceil(len_ofseg);
paax = [];                                                  % Observation vector
paay = [];                                                  % Observation vector
z = 1;                                                      % Index counter
n = 1;                                                      % Initial segment
paax(z) = 0;                                                % Initial values
paay(z) = PAA(i, n);                                        % Initial values
z = z + 1;                                                  % Incrementing index counter
for n = 2:c
    paax(z) = paax(z - 1) + len_ofseg;                      % Getting edge points
    paay(z) = PAA(i, n-1);                                  % Getting edge points
    z = z + 1;                                              % Increment index
    paax(z) = paax(z-1);                                    % Next segment
    paay(z) = PAA(i, n);                                    % Next segment
    z = z + 1;                                              % Increment index counter
end

% Plotting PAA segment
plot(paax, paay);
hold on
t = linspace(0,s(2),s(2));
scatter(t, data(i, :), "filled")

end